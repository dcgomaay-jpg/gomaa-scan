'use strict';
const assert = require('node:assert/strict');
const cvModule = require('../vendor/opencv.js');
require('../scan-core.js');
const { performance } = require('node:perf_hooks');
function contains(points, x, y) {
  return points.every((p, i) => {
    const q = points[(i + 1) % points.length];
    return (q.x - p.x) * (y - p.y) - (q.y - p.y) * (x - p.x) >= 0;
  });
}
function fixture(background, paper, points, printed = true) {
  const width = 480, height = 640, data = new Uint8ClampedArray(width * height * 4);
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const inside = points && contains(points, x, y);
    const color = inside ? paper : background;
    const ink = printed && inside && x > 145 && x < 325 && y > 190 && y < 450 && y % 22 < 3;
    const i = (y * width + x) * 4;
    for (let c = 0; c < 3; c++) data[i + c] = ink ? 35 : color[c];
    data[i + 3] = 255;
  }
  return { width, height, data };
}
cvModule.then(cv => {
  try {
    const scanner = GomaaScanCore.create(cv);
    const points = [{ x: 80, y: 80 }, { x: 380, y: 100 }, { x: 400, y: 550 }, { x: 60, y: 530 }];
    const cases = [
      ['dark desk', [55, 45, 40], [235, 235, 230], points],
      ['colored desk / gray paper', [160, 180, 210], [170, 170, 170], points],
      ['low contrast', [210, 210, 210], [230, 230, 230], points],
      ['blank paper', [80, 75, 70], [240, 240, 235], points, false],
      ['small paper', [70, 60, 50], [240, 240, 240], [{x:145,y:165},{x:335,y:165},{x:335,y:455},{x:145,y:455}]],
    ];
    for (const [name, bg, paper, expected, printed] of cases) {
      const frame = fixture(bg, paper, expected, printed);
      const start = performance.now();
      for (const fast of [true, false]) {
        const result = scanner.detect(frame, { fast });
        assert.equal(result.found, true, `${name}: ${fast ? 'live' : 'capture'} not found`);
        assert.equal(result.safeToCrop, true);
        for (let i = 0; i < 4; i++) assert.ok(Math.hypot(result.points[i].x - expected[i].x, result.points[i].y - expected[i].y) < 12, `${name}: wrong corner`);
        const warped = scanner.warp(frame, result.points);
        const enhanced = scanner.enhance(warped, { filter: 'auto' });
        assert.equal(enhanced.data.length, enhanced.width * enhanced.height * 4);
        assert.ok(enhanced.data.every(Number.isFinite));
      }
      console.log(`PASS ${name} (${Math.round(performance.now() - start)} ms for live + capture + processing)`);
    }
    for (const fast of [true, false]) {
      const noPage = scanner.detect(fixture([220,220,220], [220,220,220], null), { fast });
      assert.equal(noPage.found, false, 'uniform background must not invent a page');
      assert.equal(noPage.safeToCrop, false);
    }
    console.log('PASS no page / no invented crop');
    const original = fixture([100,80,60], [235,235,235], points);
    const before = new Uint8ClampedArray(original.data);
    scanner.enhance(original, { filter: 'auto' });
    assert.deepEqual(original.data, before, 'enhancement must preserve the source for optional editing');
    console.log('PASS original preserved');
    const stampIndex = (480 * 480 + 200) * 4;
    original.data.set([170, 35, 40, 255], stampIndex);
    const colorResult = scanner.enhance(original, { filter: 'auto' });
    assert.ok(colorResult.data[stampIndex] > colorResult.data[stampIndex + 1] * 2, 'red stamps must remain colored');
    console.log('PASS colored stamp preserved');
    const table = fixture([70,60,50], [235,235,235], points);
    for (let y = 180; y < 465; y++) for (let x = 135; x < 335; x++) {
      if (y % 22 < 3) continue;
      const i = (y * table.width + x) * 4;
      table.data.set([195,195,195,255], i);
    }
    for (const fast of [true, false]) {
      const result = scanner.detect(table, { fast });
      assert.equal(result.found, true);
      for (let i = 0; i < 4; i++) assert.ok(Math.hypot(result.points[i].x - points[i].x, result.points[i].y - points[i].y) < 12, 'must crop the page, not its internal table');
    }
    console.log('PASS internal table does not replace page boundary');
    process.exit(0);
  } catch (error) { console.error(error); process.exit(1); }
});
